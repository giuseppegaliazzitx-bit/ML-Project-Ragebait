# Professor Example Slide Review and Design Match

I reviewed both professor example decks and matched the final deck to their expectations.

## What the examples imply

- Keep the deck in the **12-15 slide range**, with a simple final questions slide.
- Use a **straightforward undergraduate ML presentation arc**: motivation, dataset, task, preprocessing, baselines, model, experiments, metrics, conclusion, references.
- Prefer **plain language** and only explain equations or implementation details when they help the audience understand the experiment.
- Use **tables and confusion matrices** for results rather than overly polished marketing visuals.
- Include enough methodological detail to show real ML work, but avoid turning the presentation into the full report.

## Changes made in the final deck

- Reduced the story to **15 slides**.
- Used a clean white layout with a simple teal footer strip, closer to the examples than the more stylized Gemini HTML draft.
- Corrected the final numbers to match the report/complete-metrics run: binary BERT F1 **0.9222**, multiclass BERT macro F1 **0.6405**, and binary BERT confusion matrix **432 / 73 / 45 / 699**.
- Added an explicit metrics slide so the speakers can explain accuracy, precision, recall, F1, and macro F1 in presentation language.
- Kept the 4-speaker script aligned to slide ranges so each speaker has a coherent section.
- Expanded Q&A to cover likely professor questions about weak labels, macro F1, class imbalance, BERT compute cost, FFNN underperformance, OOV analysis, ethics, and future work.
