# Ragebait Detection - Audience Q&A

**Q1. Why not use only the binary detector if its F1 is much higher?**

The binary detector is better for coarse screening, but it collapses profanity, trolling, derogation, and hate speech into one positive class. The multiclass model is lower-scoring because it solves the harder diagnostic problem.

**Q2. Why is macro F1 more important than accuracy for the multiclass task?**

Accuracy can be dominated by Normal and Trolling because those classes are much larger. Macro F1 gives each class equal weight, so rare classes like Derogatory and Hate Speech still matter.

**Q3. Does BERT justify the compute cost?**

It depends on the use case. TF-IDF is better for very high-throughput filtering. BERT is justified when the system needs better recall and better separation among overlapping abuse categories.

**Q4. Why did the FFNN not outperform the linear baselines?**

The FFNN mean-pools token embeddings, which loses word order and pragmatic structure. In short text, strong TF-IDF features can capture obvious lexical cues very efficiently.

**Q5. What does 0.9054 precision mean in the binary BERT model?**

When BERT predicts that a post is abusive or ragebait, it is correct about 90.54 percent of the time.

**Q6. What does 0.9395 recall mean in the binary BERT model?**

BERT recovers about 93.95 percent of the true abusive or ragebait posts in the held-out binary test split.

**Q7. Why are Derogatory and Hate Speech still difficult?**

They are minority classes and often overlap with profanity, trolling, sarcasm, and ambiguous target language. Many errors are label-boundary errors rather than obvious vocabulary misses.

**Q8. How do we know the remaining errors are not mainly unknown words?**

The full multiclass test OOV rate is 7.83 percent, while the targeted hard-error OOV rate is 7.61 percent. The rates are similar, so vocabulary gaps are not the main explanation.

**Q9. What was the main problem with the weak-label phase?**

It measured agreement with model-generated labels from Qwen rather than agreement with human labels. It was useful engineering scaffolding but not the final scientific benchmark.

**Q10. Why use a frozen split?**

A frozen split ensures every model is trained, validated, and tested on the same rows. That makes the model comparison fair and reproducible.

**Q11. What would you change in future work?**

Use grouped splits by author or source, include conversation or reply context, and refine annotation rules for Trolling vs. Derogatory vs. Hate Speech.

**Q12. Is this safe to deploy as an automatic moderation system?**

No. The safer role is assistive triage, user-facing friction, or review prioritization. High-impact moderation decisions should include human review because false positives can suppress legitimate speech.
