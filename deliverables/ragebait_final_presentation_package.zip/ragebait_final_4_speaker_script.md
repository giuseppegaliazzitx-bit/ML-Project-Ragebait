# Ragebait Detection Final Presentation - 4 Speaker Script

## Speaker 1 - Slides 1 through 4

**Slide 1 - Title**
We are presenting our machine learning project on ragebait detection. The main story is not only that BERT performs well. The main story is that we moved from a large weak-label pipeline to a smaller but more scientifically defensible human-labeled benchmark.

The three numbers to remember are 12,490 human-labeled posts, 0.9222 F1 for the final binary BERT detector, and 0.6405 macro F1 for the final five-class BERT model. Binary F1 is higher because it only asks whether a post is normal or abusive/rage-inducing. Macro F1 is lower because the five-class version has to distinguish Normal, Profanity, Trolling, Derogatory, and Hate Speech.

**Slide 2 - Motivation**
Ragebait is content designed to provoke anger, frustration, or outrage. It is difficult because it can look similar to ordinary controversy, profanity, or genuine anger. Our goal is not to classify every emotional post as bad. The goal is to detect content that appears designed to farm negative reactions.

The feedback loop is the motivation. A bad-faith post creates reaction, reaction creates engagement, engagement can be interpreted as relevance, and then the post becomes more visible. A detector can help interrupt that loop before users feed it.

**Slide 3 - Project Arc**
The project started with Iteration 1, where we built a weak-label pipeline over 507,682 posts using Qwen through vLLM. That was useful because it proved the engineering pipeline worked, but the best weak-label score measured agreement with model-generated labels.

That is why Iteration 2 is the final benchmark. We moved to 12,490 human-labeled posts, a frozen train/validation/test split, and a model ladder from TF-IDF to BERT. The biggest scientific improvement was changing what counted as truth.

**Slide 4 - Dataset**
The final dataset has five labels. Normal has 5,053 rows, which is 40.46 percent. Trolling has 4,537 rows, or 36.33 percent. Profanity has 1,582 rows, or 12.67 percent. Derogatory has 862 rows, or 6.90 percent. Hate Speech has 456 rows, or 3.65 percent.

This imbalance matters. If we only used accuracy, the majority classes could dominate the result. That is why macro F1 is important in the multiclass task: it gives equal importance to each label, including the rare classes.

## Speaker 2 - Slides 5 through 8

**Slide 5 - Task Framing**
The same gold labels support two tasks. In the binary task, Normal maps to 0 and every other label maps to 1. That answers a screening question: should this post be treated as normal or as abusive or rage-inducing?

In the multiclass task, the model keeps all five labels. That answers a diagnostic question: is this normal language, profanity, trolling, derogatory abuse, or hate speech? The multiclass task is harder, but it is more informative because it shows where the semantic boundaries blur.

**Slide 6 - Experimental Control**
Every final model uses the same frozen 80/10/10 split. The training set has 9,992 rows, with 4,042 Normal and 5,950 abusive or ragebait-positive examples under the binary mapping. Validation has 1,249 rows, and test also has 1,249 rows.

Validation is used for model selection and checkpoint selection. The held-out test split is used for the final claims. This keeps the comparison fair because a better model score cannot come from a lucky random split.

**Slide 7 - Model Ladder**
We compare three levels of representation. Tier 1 is Logistic Regression and Linear SVC over TF-IDF unigram and bigram features. These are strong and fast lexical baselines.

Tier 2 is a feed-forward neural network. It learns token embeddings, mean-pools them, and uses hidden layers with ReLU and dropout. Tier 3 is BERT, using contextual WordPiece representations from bert-base-uncased.

The point is that BERT has to beat strong baselines, not weak straw-man models.

**Slide 8 - Implementation**
The final pipeline validates the data, maps labels, freezes splits, constructs representations, trains all model families, and saves evaluation artifacts.

For the multiclass task, the loss uses inverse-frequency class weights because rare labels need more attention. Hate Speech has the largest weight at 5.4751. BERT training uses AdamW, warmup and decay scheduling, gradient clipping, dynamic padding, and CUDA mixed precision. Binary BERT selects the best checkpoint by validation F1, while multiclass BERT selects by validation macro F1.

## Speaker 3 - Slides 9 through 12

**Slide 9 - Evaluation Metrics**
Accuracy is the share of all test examples classified correctly. Precision answers: when the model predicts abuse or ragebait, how often is it right? Recall answers: how much true abuse or ragebait does the model recover?

F1 balances precision and recall. In the multiclass setting, macro F1 is especially important because it averages performance across labels equally. That means rare labels like Derogatory and Hate Speech still count.

**Slide 10 - Binary Results**
For binary classification, BERT is the best model, but the baselines are strong. Logistic Regression reaches 0.8854 F1. Linear SVC reaches 0.8884 F1. The FFNN reaches 0.8883 F1.

The final BERT binary model reaches 0.9055 accuracy, 0.9054 precision, 0.9395 recall, and 0.9222 F1. Precision of 0.9054 means most posts flagged by BERT are truly abusive or ragebait. Recall of 0.9395 means BERT finds most of the true abusive or ragebait posts. BERT improves F1 by 0.0337 over the best non-transformer model.

**Slide 11 - Binary Diagnostics**
The binary confusion matrix makes the metric tradeoff concrete. Out of 505 true Normal examples, BERT correctly predicts 432 as Normal and incorrectly flags 73 as abusive. Out of 744 true abusive examples, it correctly catches 699 and misses 45.

So the model has more false positives than false negatives. For a moderation triage use case, that can be acceptable because false positives can go to review, while false negatives miss harmful content entirely.

**Slide 12 - Multiclass Results**
The multiclass task is harder and shows BERT's value more clearly. Logistic Regression gets 0.5524 macro F1. Linear SVC gets 0.5403 macro F1. The FFNN gets 0.5250 macro F1.

BERT reaches 0.7390 accuracy, 0.7390 micro F1, 0.6405 macro F1, and 0.7441 weighted F1. Micro F1 equals accuracy here because every example has exactly one label. Macro F1 is the key result because it treats each class equally. BERT improves macro F1 by 0.0881 over the best non-transformer baseline.

## Speaker 4 - Slides 13 through 15

**Slide 13 - Class-wise and Error Analysis**
BERT improves every class compared with Logistic Regression. Normal F1 improves from 0.8215 to 0.8772. Profanity improves from 0.6108 to 0.7349. Trolling improves from 0.6202 to 0.6853. Derogatory improves from 0.3398 to 0.4384. Hate Speech improves from 0.3696 to 0.4667.

The remaining failures are semantic boundary failures. The targeted hard-error set has 68 Trolling examples predicted as Derogatory, 25 Derogatory examples predicted as Trolling, and 2 Hate Speech examples predicted as Profanity. The OOV rate is also similar: 7.83 percent for the full test set and 7.61 percent for the hard-error subset. That means unseen words are not the main explanation.

**Slide 14 - Compute Tradeoff**
The compute story is the practical tradeoff. TF-IDF models are extremely fast. Binary Linear SVC trains in about 0.03 seconds and predicts almost instantly. Binary BERT trains in 173.3 seconds and predicts the test split in 3.41 seconds.

For multiclass, BERT trains in 279.7 seconds, and the saved validation-plus-test prediction pass takes 7.58 seconds. So the deployment decision depends on the use case. If speed and simplicity are the priority, TF-IDF is attractive. If semantic category quality matters, BERT is justified.

**Slide 15 - Conclusion**
The final findings are straightforward. First, strong baselines matter because TF-IDF models are very competitive on binary detection. Second, the FFNN does not justify its added complexity here because mean pooling loses too much sequence and pragmatic information. Third, BERT is the consistent winner across aggregate metrics and class-wise F1.

There are important limitations. The model sees isolated posts, not full conversation context. It does not know the target, author history, quotation context, or community norms. The rare test classes are also small, with only 86 Derogatory and 46 Hate Speech examples. The safest deployment role is assistive triage, not automatic punishment. The next step is grouped author/source splits, richer context, and sharper annotation guidance around borderline labels.
